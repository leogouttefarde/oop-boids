/*
 * Decompiled with CFR 0_102.
 */
package gui;

import gui.CenteredGraphicalElement;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.image.ImageObserver;

public class ImageElement
extends CenteredGraphicalElement {
    private Image image;
    private double width;
    private double height;
    private ImageObserver observer;

    public ImageElement(int x, int y, String fileName, int width, int height, ImageObserver obs) {
        super(x, y);
        this.image = Toolkit.getDefaultToolkit().getImage(fileName);
        this.width = width;
        this.height = height;
        this.observer = obs;
    }

    @Override
    public void paint(Graphics2D g2d) {
        int imageWidth = this.image.getWidth(this.observer);
        int imageHeight = this.image.getHeight(this.observer);
        AffineTransform affineT = AffineTransform.getTranslateInstance(this.getX(), this.getY());
        affineT.concatenate(AffineTransform.getScaleInstance(this.width / (double)imageWidth, this.height / (double)imageHeight));
        g2d.drawImage(this.image, affineT, this.observer);
    }

    public String toString() {
        return String.valueOf(this.image.toString()) + " image";
    }
}

