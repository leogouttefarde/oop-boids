/*
 * Decompiled with CFR 0_102.
 */
package gui;

import gui.Simulable;
import java.io.PrintStream;

class DefaultSimulator
implements Simulable {
    DefaultSimulator() {
    }

    @Override
    public void next() {
        this.message("next()");
    }

    @Override
    public void restart() {
        this.message("restart()");
    }

    private void message(String functionName) {
        System.out.println("Methode " + functionName + ": pas encore implementee!");
    }
}

