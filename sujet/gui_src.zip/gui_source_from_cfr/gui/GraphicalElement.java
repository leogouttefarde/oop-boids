/*
 * Decompiled with CFR 0_102.
 */
package gui;

import java.awt.Graphics2D;

public interface GraphicalElement {
    public void paint(Graphics2D var1);
}

