/*
 * Decompiled with CFR 0_102.
 */
package gui;

public interface Simulable {
    public void next();

    public void restart();
}

