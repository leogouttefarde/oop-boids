package utility;

/**
 * Enumération des différents type de Boid
 * 
 * @author Ilyes Kacher, Léo Gouttefarde, Nejmeddine Douma
 */
public enum Type {
	Prey, Predator, Lighter
}
